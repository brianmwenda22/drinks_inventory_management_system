// cart.js (or any appropriate name)
const { DataTypes } = require('sequelize');
const sequelize = require('../db'); // Adjust the path to your db module
const Drink = require('./Drink'); 
const User = require('./User'); 

const Cart = sequelize.define('cart', {
  cartId: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true
  }
});

// Define relationships with other tables
Cart.belongsTo(Drink);
Cart.belongsTo(User);

sequelize.sync()
  .then(() => console.log('Cart table has been successfully created'))
  .catch(error => console.error('Error creating table:', error));

module.exports = Cart;
