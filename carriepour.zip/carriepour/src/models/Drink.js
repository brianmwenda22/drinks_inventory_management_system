const { DataTypes } = require('sequelize');
const sequelize = require('../db'); // Adjust the path to your db module

const Drink = sequelize.define('drink', {
  drinkId: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true
  },
  name: {
    type: DataTypes.STRING,
    allowNull: false
  },
  image: {
    type: DataTypes.STRING,
    allowNull: true
  },
  bottleQuantity: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  price: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false
  },
  stockQuantity: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  expiration: {
    type: DataTypes.DATEONLY, // Use DATEONLY for storing only date without time
    allowNull: true
  }
});

// Add a new drink to the database
Drink.addNewDrink = async function(newDrink) {
  try {
    const drink = await Drink.create(newDrink);
    return drink; // This drink object will include the id after the insert
  } catch (error) {
    throw error;
  }
};

// Update drink stock in the database
Drink.updateDrinkStock = async function(drinkId, quantity) {
  try {
    const [updateCount, [updatedDrink]] = await Drink.update(
      { stockQuantity: sequelize.literal(`stockQuantity + ${quantity}`) },
      { where: { id: drinkId }, returning: true }
    );

    if (updateCount === 1) {
      return updatedDrink; // The updated drink instance
    } else {
      throw new Error('Drink not found');
    }
  } catch (error) {
    throw error;
  }
};

sequelize.sync()
  .then(() => console.log('Drinks table has been successfully created'))
  .catch(error => console.error('Error creating table:', error));

module.exports = Drink;

