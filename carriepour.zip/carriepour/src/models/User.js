const bcrypt = require('bcryptjs');
const { Sequelize, DataTypes } = require('sequelize');

// Set up a new instance of Sequelize
const sequelize = new Sequelize('carriepour_drinks_inventory', 'carrie', 'cp123456', {
  host: 'localhost',
  dialect: 'mysql'
});

// Define a model
const User = sequelize.define('user', {
  // Attributes
  userId: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true
  },
  username: DataTypes.STRING,
  email: DataTypes.STRING,
  password: DataTypes.STRING,
  /*userType: {
    type: DataTypes.STRING,
    allowNull: false,
    defaultValue: 'Employee',
  },*/
});

// Sync all models with the database
sequelize.sync()
  .then(() => console.log('Users tables have been successfully created'))
  .catch(error => console.error('Error creating tables', error));

User.createWithHash = async function(newUser) {
  try {
    // Hash the password
    const hash = await bcrypt.hash(newUser.password, 10);
    newUser.password = hash;

    // Create a new user with the hashed password
    const user = await User.create(newUser);
    return user; // This user object will include the id after the insert
  } catch (error) {
    throw error;
  }
};

module.exports = User;
