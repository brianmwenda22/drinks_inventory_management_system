const { Sequelize } = require('sequelize');
require('dotenv').config(); // Load environment variables from .env file

// Create a Sequelize instance with database connection details
const sequelize = new Sequelize(process.env.DB_NAME, process.env.DB_USER, process.env.DB_PASSWORD, {
  host: process.env.DB_HOST,
  dialect: 'mysql', // Use 'mysql' as the database dialect
  // Additional options, if needed
  pool: {
    max: 5,
    min: 0,
    acquire: 30000,
    idle: 10000
  },
  define: {
    freezeTableName: true // This option stops Sequelize from pluralizing table names
  }
});

// Test the connection
sequelize.authenticate()
  .then(() => {
    console.log('Connected to the MySQL server with Sequelize.');
  })
  .catch((err) => {
    console.error('Unable to connect to the MySQL server:', err);
  });

module.exports = sequelize;
