const express = require('express');
const bcrypt = require('bcryptjs');
const db = require('../db'); // Your database connection file

const router = express.Router();

router.post('/login', (req, res) => {
  const { username, password } = req.body;
  
  
  // Query to find the user in the database
  db.query('SELECT * FROM users WHERE username = ?', [username], (err, results) => {
    if (err) {
      res.status(500).send('Server error');
    } else if (results.length === 0) {
      res.status(401).send('No such user found');
    } else {
      const user = results[0];
      
      // Compare hashed password
      bcrypt.compare(password, user.password, (err, isMatch) => {
        if (err) {
          res.status(500).send('Server error');
        } else if (isMatch) {
          // Passwords match, log in the user
          // Set up your session or JWT token here
          res.redirect('/dashboard'); // Redirect to user's dashboard
        } else {
          // Passwords do not match
          res.status(401).send('Password incorrect');
        }
      });
    }
  });
  // Assuming successful login
  req.session.userId = user.id; // Set the user ID in the session

});

module.exports = router;
