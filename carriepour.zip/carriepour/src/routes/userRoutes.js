const express = require('express');
const bcrypt = require('bcryptjs');
const User = require('../models/User'); // This should be a Sequelize model

const router = express.Router();

// POST route for creating a new user
router.post('/register', async (req, res) => {
  const { username, email, password, confirmPassword } = req.body;

  // Validate password match
  if (password !== confirmPassword) {
    return res.status(400).send('Passwords do not match');
  }

  try {
    // Hash the password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create new user object
    const newUser = {
      username,
      email,
      password: hashedPassword, // Store the hashed password
      userType: 'User', // Assign a default userType if necessary
    };

    // Save new user to the database using Sequelize
    const user = await User.create(newUser);

    // Redirect to homepage after successful registration
    res.redirect('/homepage.html'); // Make sure this path is correct
  } catch (error) {
    console.error(error);
    res.status(500).send('Server error');
  }
});

// POST route for user login
router.post('/login', async (req, res) => {
  const { username, password } = req.body;

  try {
    // Find user by username using Sequelize
    const user = await User.findOne({ where: { username } });
    if (!user) {
      return res.status(401).send('Login failed, username not found');
    }

    // Check if the password is correct
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(401).send('Login failed, incorrect password');
    }

    // Passwords match, redirect to homepage
    res.redirect('/homepage.html'); // Make sure this path is correct
  } catch (error) {
    console.error(error);
    res.status(500).send('Server error');
  }
  
});



module.exports = router;
