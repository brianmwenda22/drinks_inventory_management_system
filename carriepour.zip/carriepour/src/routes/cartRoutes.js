// cartRoutes.js (or any appropriate name)
const express = require('express');
const router = express.Router();
const Cart = require('../models/Cart'); // Adjust the path to your Cart model

// Route to add an item to the cart
router.post('/add-to-cart', async (req, res) => {
  try {
    const { drinkId, userId } = req.body;

    // Create a new entry in the Cart table
    const cartEntry = await Cart.create({ drinkId, userId });

    res.json({ success: true, cartEntry });
  } catch (error) {
    console.error('Error adding to cart:', error);
    res.status(500).json({ success: false, error: 'Failed to add to cart' });
  }
});

module.exports = router;
