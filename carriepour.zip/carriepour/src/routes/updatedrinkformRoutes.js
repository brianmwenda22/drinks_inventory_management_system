const express = require('express');
const router = express.Router();
const Drink = require('../models/Drink'); // Adjust the path to your Drink model

// Route to render the update drink form
router.get('/update-drink-form', async (req, res) => {
    try {
        const drinkId = req.query.id;
        const drink = await Drink.findByPk(drinkId);

        if (!drink) {
            return res.status(404).send('Drink not found');
        }

        res.render('update-drink-form.html', { drink });
    } catch (error) {
        console.error('Error:', error);
        res.status(500).send('Internal Server Error');
    }
});

// Route to handle updating the drink in the database
router.post('/update-drink', async (req, res) => {
    try {
        const drinkId = req.body.id;
        const updatedDrinkData = {
            name: req.body.name,
            bottleQuantity: req.body.bottleQuantity,
            price: req.body.price,
            stockQuantity: req.body.stockQuantity,
            // Add other fields as needed
        };

        const updatedDrink = await Drink.update(updatedDrinkData, {
            where: { id: drinkId },
            returning: true,
        });

        res.json({ success: true, updatedDrink });
    } catch (error) {
        console.error('Error:', error);
        res.status(500).json({ success: false, error: 'Internal Server Error' });
    }
});

module.exports = router;
