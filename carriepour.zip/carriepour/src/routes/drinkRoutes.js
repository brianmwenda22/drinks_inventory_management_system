const express = require('express');
const multer = require('multer');
const path = require('path');
const { sequelize } = require('../db'); // Import the sequelize instance
const Drink = require('../models/Drink');
//const Cart = require('../models/Cart');

const router = express.Router();

// Set up storage engine for multer
const storage = multer.diskStorage({
  destination: function(req, file, cb) {
    cb(null, './public/uploads/');
  },
  filename: function(req, file, cb) {
    cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
  }
});

// Initialize upload variable with multer storage engine
const upload = multer({ storage: storage });

// POST route for adding new drink
router.post('/add-drink', upload.single('image'), async (req, res) => {
  try {
    const { name, bottleQuantity, price, stockQuantity, expiration } = req.body;
    const image = req.file ? req.file.filename : ''; // Store only the filename

    const newDrink = await Drink.create({
      name,
      bottleQuantity,
      price,
      stockQuantity,
      expiration,
      image // Assuming your Drink model has a field for image
    });
    
    res.redirect('/homepage.html'); // Adjust the redirect as necessary
  } catch (error) {
    res.status(500).send(error.message);
  }
});


router.get('/add-drink-form', (req, res) => {
  res.sendFile(path.join(__dirname, '../../public/add-drink.html'));
});


// POST route for updating drink stock
router.post('/update-stock', async (req, res) => {
  try {
    const { drinkId, quantity } = req.body;
    
    await Drink.update(
      { stockQuantity: sequelize.literal(`stockQuantity + ${quantity}`) },
      { where: { id: drinkId } }
    );

    res.redirect('/inventory'); // Adjust the redirect as necessary
  } catch (error) {
    res.status(500).send(error.message);
  }
});

// GET route to fetch all drinks
router.get('/drinks', async (req, res) => {
  try {
    const drinks = await Drink.findAll({ order: [['name', 'ASC']] });
    res.json(drinks);
  } catch (error) {
    res.status(500).send('Server error');
  }
});

// In your drink routes file
/*router.delete('/drinks/:id', async (req, res) => {
  try {
    const id = req.params.id;
    const result = await Drink.destroy({ where: { id } });

    if (result) {
      res.json({ success: true, message: 'Drink deleted' });
    } else {
      res.status(404).json({ success: false, message: 'Drink not found' });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error deleting drink' });
  }
});*/
// Server-side route to handle the delete request
router.delete('/delete-drink/:id', async (req, res) => {
  const { id } = req.params;
  try {
    const result = await Drink.destroy({ where: { id } });
    if (result > 0) {
      res.json({ success: true });
    } else {
      res.status(404).json({ success: false, message: 'Drink not found' });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error deleting drink' });
  }
});


module.exports = router;

