const urlParams = new URLSearchParams(window.location.search);
const drinkId = urlParams.get('drinkId');
//const drinkId= {drinkId};

document.addEventListener('DOMContentLoaded', function() {
  // Assuming you have obtained drinkId from somewhere in your code
  // For example, if it's a parameter in the URL, you can extract it

  // Get drinkId from the URL (example: /drinks/{drinkId})
  

  // Fetch details of the current drink from the server
  if (drinkId !== null) {
    fetch(`/drink/${drinkId}`)
      .then(response => {
      if (!response.ok) {
        throw new Error(`Failed to delete the drink. Status: ${response.status}`);
      }
      // Check if the response is JSON
      const contentType = response.headers.get('content-type');
      if (contentType && contentType.includes('application/json')) {
        return response.json();
      } else {
        // If not JSON, handle the non-JSON response here
        console.error('Non-JSON response received:', response);
        // You can provide a custom error message or handle the HTML response appropriately
        throw new Error('Unexpected response format');
      }
    })
      .then(drink => {
        // Display current details in the form
        document.getElementById('currentName').value = drink.name;
        // Include similar lines for other details
      })
      .catch(error => console.error('Error fetching drink details:', error.message));
  } else {
    console.error('Error: drinkId is null');
  }
});


// Function to handle Add to Cart action
function addToCart(drinkId) {
  // Fetch user ID from the server based on the current user session
  fetch('/get-user-id')
    .then(response => {
      if (!response.ok) {
        throw new Error('Failed to fetch user ID');
      }
      return response.json();
    })
    .then(userId => {
      // Send add to cart details to the server
      fetch('/add-to-cart', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ drinkId, userId })
      })
        .then(response => {
          if (!response.ok) {
            throw new Error('Failed to add to cart');
          }
          return response.json();
        })
        .then(data => {
          // Update UI to reflect the item added to cart
          // Additional logic to update the cart UI
        })
        .catch(error => console.error('Error adding to cart:', error.message));
    })
    .catch(error => console.error('Error fetching user ID:', error.message));
}

//let currentDrinkId = null;

function confirmDeletion(drinkId) {
  //currentDrinkId = drinkId;
  document.getElementById('deleteConfirmationPopup').style.display = 'block';
}

function closeDeletePopup() {
  document.getElementById('deleteConfirmationPopup').style.display = 'none';
}

function deleteDrink() {
  fetch(`/drink/${drinkId}`, { method: 'DELETE' })
     .then(response => response.text())
    .then(data => {
      if (data.success) {
        // Remove the drink card from the DOM
        const drinkCard = document.getElementById(`drink-${drinkId}`);
        if (drinkCard) {
          drinkCard.remove();
        }

        // Close the delete confirmation popup
        closeDeletePopup();

        // Redirect to the homepage and reload the screen
        window.location.href = '/homepage.html'; // Replace with the actual URL of your homepage
      } else {
        alert('Failed to delete the drink: ' + error.message);
      }
    })
    .catch(error => {
      console.error('Error:', error);
      alert('An error occurred while deleting the drink: ' + error.message);
    });
}




function submitForm() {
    // Gather updated data from the form
    const newName = document.getElementById('newName').value;
    // Include similar lines for other details

    // Send updated data to the server for processing
    fetch(`/update-drink/${currentDrinkId}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ newName })
        // Include similar lines for other details
    })
    .then(response => response.json())
    .then(data => {
        // Redirect to the homepage after updating
        window.location.href = '/homepage.html';
    })
    .catch(error => console.error('Error:', error));
}


document.addEventListener('DOMContentLoaded', function() {
  fetch('/drinks')
    .then(response => response.json())
    .then(drinks => {
      //const urlParams = new URLSearchParams(window.location.search);
      //const drinkId = urlParams.get('drinkId');
      const container = document.getElementById('drinks-container');
      
      drinks.forEach(drink => {
        const imageUrl = `/uploads/${drink.image}`;
        
        const drinkDiv = document.createElement('div');
        drinkDiv.className = 'drink-card';
        drinkDiv.innerHTML = `
          <img src="${imageUrl}" alt="${drink.name}" alt="${drink.name}">
          <h3>${drink.name}</h3>
          <p>Bottle Quantity: ${drink.bottleQuantity} ML</p>
          <p>Price: Ksh ${drink.price}</p>
          <p>Expiration Date: ${drink.expiration ? new Date(drink.expiration).toLocaleDateString() : 'Not specified'}</p>
          <button onclick="confirmDeletion(${drinkId})" class="delete-btn">Delete</button>
          <button onclick="openUpdateDrinkForm(${drinkId})" class="update-btn">Update</button>
          <button onclick="addToCart(${drinkId})" class="add-to-cart-btn">Add to Cart</button>
        `;
        container.appendChild(drinkDiv);
      });
    })
    .catch(error => console.error('Error:', error));
});


// Call this function to confirm deletion and show the popup
function confirmDeletion(drinkId) {
  // Store the drink ID in a data attribute of the confirm button
  document.getElementById('confirmDeleteButton').dataset.drinkId = drinkId;
  // Show the delete confirmation popup
  document.getElementById('deleteConfirmationPopup').style.display = 'block';
}

// Call this function when the delete is confirmed
function deleteDrink() {
  const drinkId = document.getElementById('confirmDeleteButton').dataset.drinkId;
  // Proceed with the deletion process, for example, by making a fetch call to your API
  // ...
}

// Call this function to close the delete confirmation popup
function closeDeletePopup() {
  document.getElementById('deleteConfirmationPopup').style.display = 'none';
}


// ... (rest of the logic)
