document.addEventListener('DOMContentLoaded', function () {
  // Fetch sales data from the server
  fetch('/sales')
    .then(response => response.json())
    .then(sales => {
      const salesList = document.getElementById('sales-list');

      sales.forEach(sale => {
        const saleCard = document.createElement('li');
        saleCard.className = 'sales-card';

        // Extracted data from the sale object
        const { username, name, bottleQuantity, price, createdAt } = sale;

        // Create HTML structure for the sales card
        saleCard.innerHTML = `
          <h2>${username}'s Sale</h2>
          <p>Drink: ${name}</p>
          <p>Bottle Quantity: ${bottleQuantity} ML</p>
          <p>Price: Ksh ${price}</p>
          <p>Created At: ${new Date(createdAt).toLocaleDateString()}</p>
        `;

        salesList.appendChild(saleCard);
      });
    })
    .catch(error => console.error('Error:', error));
});
