document.addEventListener('DOMContentLoaded', function() {
    // Fetch details of the current drink from the server
    // (Assuming you have an endpoint to fetch a single drink)
    fetch(`/drinks/${currentDrinkId}`)
        .then(response => response.json())
        .then(drink => {
            // Display current details in the form
            document.getElementById('currentName').value = drink.name;
            // Include similar lines for other details
        })
        .catch(error => console.error('Error:', error));
});

function submitForm() {
    // Gather updated data from the form
    const newName = document.getElementById('newName').value;
    // Include similar lines for other details

    // Send updated data to the server for processing
    fetch(`/update-drink/${currentDrinkId}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ newName })
        // Include similar lines for other details
    })
    .then(response => response.json())
    .then(data => {
        // Redirect to the homepage after updating
        window.location.href = '/homepage.html';
    })
    .catch(error => console.error('Error:', error));
}
