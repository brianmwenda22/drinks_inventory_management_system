document.addEventListener('DOMContentLoaded', function() {
    fetch('/cart')
    .then(response => response.json())
    .then(cartItems => {
        updateCartDisplay(cartItems);
    })
    .catch(error => console.error('Error:', error));
});

function updateCartDisplay(cartItems) {
    const cartContainer = document.getElementById('cart-items');
    let subtotal = 0;
    let discount = 0;

    cartItems.forEach(item => {
        subtotal += item.totalPrice;
        discount += item.discount; // Assuming there's a discount field per item
        
        const itemDiv = document.createElement('div');
        itemDiv.className = 'cart-item';
        itemDiv.innerHTML = `
            <p>${item.drinkName} - $${item.price} x ${item.quantity}</p>
            <p>Subtotal: $${item.totalPrice.toFixed(2)}</p>
        `;
        cartContainer.appendChild(itemDiv);
    });

    document.getElementById('subtotal').textContent = `$${subtotal.toFixed(2)}`;
    document.getElementById('discount').textContent = `$${discount.toFixed(2)}`;
    document.getElementById('total').textContent = `$${(subtotal - discount).toFixed(2)}`;
}

function checkout() {
    fetch('/checkout', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({}) // Send necessary data
    })
    .then(response => response.json())
    .then(data => {
        // Handle the successful checkout here
        window.location.href = '/homepage.html'; // Redirect to homepage
    })
    .catch(error => console.error('Error:', error));
}
