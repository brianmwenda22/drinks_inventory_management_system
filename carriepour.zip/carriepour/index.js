const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const session = require('express-session');
const mysql = require('mysql');
require('dotenv').config(); // Load environment variables from .env file
const { Sequelize } = require('sequelize');
const app = express();
const crypto = require('crypto');
const secretKey = crypto.randomBytes(32).toString('hex');
console.log(secretKey);



app.use(express.static(path.join(__dirname, 'public')));

const sequelize = require('./src/db'); // The path to your database connection file
const Drink = require('./src/models/Drink');
//const Cart = require('./src/models/Cart');
const User = require('./src/models/User');

// Sync all models that aren't already in the database
//sequelize.sync()
//  .then(() => console.log('Tables created successfully.'))
//  .catch(error => console.error('Error creating tables:', error));


// Import routes
const userRoutes = require('./src/routes/userRoutes');
const drinkRoutes = require('./src/routes/drinkRoutes');
const authRoutes = require('./src/routes/authRoutes');
//const cartRoutes = require ('./src/routes/cartRoutes');
const updatedrinkformRoutes = require('./src/routes/updatedrinkformRoutes');
const cartRoutes = require('./src/routes/cartRoutes');



// Create an Express application


// Set up middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Set up session middleware
app.use(session({
  secret: secretKey, // Replace with your secret key
  resave: false,
  saveUninitialized: true,
  cookie: { secure: true } // Set to true if you're on HTTPS
}));


// Route to get user ID based on the current user session (replace with your actual logic)
app.get('/get-user-id', (req, res) => {
  // For simplicity, let's assume there's a session ID in the request headers
  const sessionId = req.headers['session-id'];

  // Replace this with your actual logic to map session ID to user ID
  const user = user.find(user => user.id === sessionId);

  if (user) {
    res.json(user.id);
  } else {
    res.status(404).json({ error: 'User not found' });
  }
});

// Static files middleware to serve files from the public directory
app.use(express.static(path.join(__dirname, 'public')));

// Use routes
app.use(userRoutes);
app.use(drinkRoutes);
app.use(authRoutes);
app.use(updatedrinkformRoutes);
app.use(cartRoutes);



// Set up a MySQL connection (not the actual connection, just the configuration)
const db = mysql.createConnection({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME
});

// Connect to MySQL
db.connect((err) => {
  if (err) {
    console.error('Error connecting to the database: ', err);
    return;
  }
  console.log('Connected to MySQL database.');
});

// Set the database connection globally
global.db = db;


// Start the server
const PORT = process.env.PORT || 3000;
  app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});

module.exports = app;
